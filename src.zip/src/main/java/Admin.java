import java.sql.*;
import java.util.*;
import org.apache.commons.lang3.StringUtils;


public class Admin {
    public static void viewStats() {
        try {
            Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db");

            // SQL query to retrieve application statistics for downloads and uploads from the Library table
            String statsQuery = "SELECT SUM(downloads) AS totalDownloads, " +
                    "SUM(uploads) AS totalUploads " +
                    "FROM Library";
            PreparedStatement statsStatement = connection.prepareStatement(statsQuery);
            ResultSet statsResultSet = statsStatement.executeQuery();

            if (statsResultSet.next()) {
                int totalDownloads = statsResultSet.getInt("totalDownloads");
                int totalUploads = statsResultSet.getInt("totalUploads");

                System.out.println("Library Statistics:");
                System.out.println("Total Downloads: " + totalDownloads);
                System.out.println("Total Uploads: " + totalUploads);
            }

            statsResultSet.close();
            statsStatement.close(); // Corrected the typo here
            connection.close();
        } catch (SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    public static void addUser(String email, String phoneNum, String fullName, String username, String userID, String role, String password) {
        if (userID == null || phoneNum == null || fullName == null || username == null || email == null || password == null) {
            System.out.println("Please enter a valid entry.");
            return;
        }
    
        if (!StringUtils.isNumeric(phoneNum) || phoneNum.length() != 10) {
            System.out.println("Please enter the correct integers.");
            return;
        }
    
        try {
            Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db");
    
            String insertQuery = "INSERT INTO Users (email, phone_num, fullname, username, UserID, role, password) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement insertStatement = connection.prepareStatement(insertQuery);
    
            insertStatement.setString(1, email.toLowerCase().trim());
            insertStatement.setInt(2, Integer.parseInt(phoneNum));
            insertStatement.setString(3, fullName.toUpperCase().trim());
            insertStatement.setString(4, username.toLowerCase().trim());
            insertStatement.setInt(5, Integer.parseInt(userID));
            insertStatement.setString(6, role.toLowerCase().trim());
            insertStatement.setString(7, PasswordHandler.encryptPassword(password));
    
            int rowsAffected = insertStatement.executeUpdate();
    
            if (rowsAffected > 0) {
                System.out.println("User added successfully.");
            } else {
                System.out.println("Failed to add user.");
            }
    
            insertStatement.close();
            connection.close();
        } catch (SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }
    
    

    public static void deleteUser(String username) {
        try {
            Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db");

            // SQL query to delete a user by username
            String deleteQuery = "DELETE FROM Users WHERE username = ?";
            PreparedStatement deleteStatement = connection.prepareStatement(deleteQuery);
            deleteStatement.setString(1, username.toLowerCase().trim());

            int rowsAffected = deleteStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("User deleted successfully.");
            } else {
                System.out.println("Failed to delete user.");
            }

            deleteStatement.close();
            connection.close();
        } catch (SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    public static void promoteToAdmin(String username) {
        try {
            Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db");

            // SQL query to promote a user to an admin
            String promoteQuery = "UPDATE Users SET role = 'admin' WHERE username = ?";
            PreparedStatement promoteStatement = connection.prepareStatement(promoteQuery);
            promoteStatement.setString(1, username.toLowerCase().trim());

            int rowsAffected = promoteStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("User promoted to admin successfully.");
            } else {
                System.out.println("Failed to promote user to admin.");
            }

            promoteStatement.close();
            connection.close();
        } catch (SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    public static void demoteToUser(String username) {
        try {
            Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db");

            // SQL query to demote an admin to a user
            String demoteQuery = "UPDATE Users SET role = 'user' WHERE username = ?";
            PreparedStatement demoteStatement = connection.prepareStatement(demoteQuery);
            demoteStatement.setString(1, username.toLowerCase().trim());

            int rowsAffected = demoteStatement.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Admin demoted to user successfully.");
            } else {
                System.out.println("Failed to demote admin to user.");
            }

            demoteStatement.close();
            connection.close();
        } catch (SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    public static String getUserType(String username) {
        String userType = null;
        try {
            Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db");
    
            String userTypeQuery = "SELECT role FROM Users WHERE username = ?";
            PreparedStatement userTypeStatement = connection.prepareStatement(userTypeQuery);
            userTypeStatement.setString(1, username.toLowerCase().trim());
    
            ResultSet userTypeResultSet = userTypeStatement.executeQuery();
    
            if (userTypeResultSet.next()) {
                userType = userTypeResultSet.getString("role");
            }
    
            userTypeResultSet.close();
            userTypeStatement.close();
            connection.close();
        } catch (SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
        return userType;
    }

    public static void viewAllUsers() {
        try {
            Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db");
    
            // SQL query to retrieve all user details
            String usersQuery = "SELECT * FROM Users";
            PreparedStatement usersStatement = connection.prepareStatement(usersQuery);
            ResultSet usersResultSet = usersStatement.executeQuery();
    
            System.out.println("All Users:");
            System.out.println("------------------------------------------------------------------------------------------------------------------------------------");
            System.out.printf("%-10s | %-15s | %-30s | %-15s | %-20s | %s%n",
                    "User ID", "Username", "Email", "Phone Number", "Full Name", "Role");
            System.out.println("------------------------------------------------------------------------------------------------------------------------------------");
    
            while (usersResultSet.next()) {
                int userID = usersResultSet.getInt("UserID");
                String username = usersResultSet.getString("username");
                String email = usersResultSet.getString("email");
                String phoneNum = usersResultSet.getString("phone_num");
                String fullName = usersResultSet.getString("fullname");
                String role = usersResultSet.getString("role");
    
                System.out.printf("%-10d | %-15s | %-30s | %-15s | %-20s | %s%n",
                        userID, username, email, phoneNum, fullName, role);
            }
    
            System.out.println("------------------------------------------------------------------------------------------------------------------------------------");
    
            usersResultSet.close();
            usersStatement.close();
            connection.close();
        } catch (SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }
    
    


    public static void viewAdminDashboard() {
        Scanner input = new Scanner(System.in);

        while (true) {
            System.out.println("Admin Dashboard:");
            System.out.println("1 : View Library Statistics");
            System.out.println("2 : Add User");
            System.out.println("3 : Delete User");
            System.out.println("4 : Promote User to Admin");
            System.out.println("5 : Demote Admin to User");
            System.out.println("6 : Check User Type");
            System.out.println("7 : View All Users");
            System.out.println("8 : Exit");
            System.out.print("Enter your choice: ");

            int choice = input.nextInt();
            input.nextLine();  // Consume newline left-over

            switch (choice) {
                case 1:
                    viewStats();
                    break;
                case 2:

                    System.out.print("Enter your email: ");
                    String email = input.nextLine();

                    System.out.print("Enter your phone number: ");
                    String phoneNum = input.nextLine();


                    System.out.print("Enter your full name: ");
                    String fullName = input.nextLine();

                    System.out.print("Enter a username: ");
                    String username = input.nextLine();

                    System.out.print("Enter a userID for your account: ");
                    String userID = input.nextLine();

                    System.out.print("Enter role (admin/user): ");
                    String role = input.nextLine();

                    System.out.print("Enter a password for your account: ");
                    String password = input.nextLine();

                    addUser(email, phoneNum, fullName, username, userID, role, password);
                    break;

                case 3:
                    System.out.print("Enter username to delete: ");
                    String deleteUsername = input.nextLine();
                    deleteUser(deleteUsername);
                    break;
                case 4:
                    System.out.print("Enter username to promote to admin: ");
                    String promoteUsername = input.nextLine();
                    promoteToAdmin(promoteUsername);
                    break;
                case 5:
                    System.out.print("Enter username to demote to user: ");
                    String demoteUsername = input.nextLine();
                    demoteToUser(demoteUsername);
                    break;
                    case 6:
                    // Check User Type
                    System.out.print("Enter username to check: ");
                    String checkUsername = input.nextLine();
                    String userType = getUserType(checkUsername);
                    if (userType != null) {
                        System.out.println(checkUsername + " is a " + userType);
                    } else {
                        System.out.println("User not found.");
                    }
                    break;
                    case 7:
                    viewAllUsers();
                    break;
                    case 8:
                    System.out.println("Exiting Admin Dashboard...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

}
