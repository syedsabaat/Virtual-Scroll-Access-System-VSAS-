
import java.io.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Date;

public class FileSystem {

    private static String url = "jdbc:sqlite:database.db";
    private static int randomFileID;
    private static String randomFilename;

    private static int totalNumOfFile = 0;


    private static String getCurrentDate() {
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date();
        return formatter.format(date);
    }

public static void addFile(String filePath, String filePassword, int uploaderID) {
    try {
        Connection connection = DriverManager.getConnection(url);

        // Check if the file with the same name exists and has the same uploader
        String checkSql = "SELECT uploaderID FROM Library WHERE filename = ?";
        PreparedStatement checkStatement = connection.prepareStatement(checkSql);
        checkStatement.setString(1, new File(filePath).getName());
        ResultSet rs = checkStatement.executeQuery();

        if (rs.next()) {
            int existingUploaderID = rs.getInt("uploaderID");

            if (existingUploaderID == uploaderID) {
                System.out.print("A file with the same name already exists. Do you want to update it? (yes/no): ");

                Scanner scanner = new Scanner(System.in);
                String response = scanner.nextLine();

                if ("yes".equalsIgnoreCase(response)) {
                    String updateSql;

                    if ("None".equals(filePassword)) {
                        updateSql = "UPDATE Library SET data = ?, date = ?, uploaderID = ?, uploads = uploads + 1 WHERE filename = ?";
                    } else {
                        updateSql = "UPDATE Library SET data = ?, password = ?, date = ?, uploaderID = ?, uploads = uploads + 1 WHERE filename = ?";
                    }

                    PreparedStatement updateStatement = connection.prepareStatement(updateSql);
                    FileInputStream updateFileInputStream = new FileInputStream(filePath);
                    updateStatement.setBinaryStream(1, updateFileInputStream, (int) new File(filePath).length());

                    if (!"None".equals(filePassword)) {
                        updateStatement.setString(2, filePassword);
                        updateStatement.setString(3, getCurrentDate());
                        updateStatement.setInt(4, uploaderID);
                        updateStatement.setString(5, new File(filePath).getName());
                    } else {
                        updateStatement.setString(2, getCurrentDate());
                        updateStatement.setInt(3, uploaderID);
                        updateStatement.setString(4, new File(filePath).getName());
                    }

                    updateStatement.executeUpdate();
                    updateFileInputStream.close();

                    System.out.println("File updated in the Library");
                }
            } else {
                System.out.println("A file with the same name already exists. Cannot upload.");
            }
            return;
        }

        String sql;
        if ("None".equals(filePassword)) {
            sql = "INSERT INTO Library (filename, filetype, data, date, uploaderID, uploads) VALUES (?, ?, ?, ?, ?, 1)";
        } else {
            sql = "INSERT INTO Library (filename, filetype, data, password, date, uploaderID, uploads) VALUES (?, ?, ?, ?, ?, ?, 1)";
        }

        PreparedStatement statement = connection.prepareStatement(sql);
        File file = new File(filePath);
        FileInputStream fileInputStream = new FileInputStream(file);

        statement.setString(1, file.getName());
        statement.setString(2, getFileType(filePath)); // Assuming you have this method
        statement.setBinaryStream(3, fileInputStream, (int) file.length());

        if (!"None".equals(filePassword)) {
            statement.setString(4, filePassword);
            statement.setString(5, getCurrentDate());
            statement.setInt(6, uploaderID);
        } else {
            statement.setString(4, getCurrentDate());
            statement.setInt(5, uploaderID);
        }

        statement.executeUpdate();
        fileInputStream.close();
        connection.close();

        System.out.println("File added to the Library");
    } catch (SQLException | IOException ex) {
        ex.printStackTrace();
    }
}


    public static void getRandomFile() {
        try {
            Connection connection = DriverManager.getConnection(url);

            ResultSet resultSetA = connection.createStatement().executeQuery("SELECT COUNT(*) FROM Library");
            int totalCount = resultSetA.getInt(1);

            // make a random number between 1 and count
            Random rand = new Random();
            int randomNum = rand.nextInt(totalCount) + 1;

            String sql = "SELECT * FROM Library WHERE Id = " + randomNum + ";";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                randomFileID = resultSet.getInt(1);
                randomFilename = resultSet.getString(2);
                System.out.println("        *****Scroll of the Day*****");
                System.out.println("----------------------------------------------");
                System.out.println("       fileID : " + randomFileID + "  filename : " + randomFilename);
                System.out.println("----------------------------------------------");
            } else {
                System.out.println("No file exists.");
            }

            connection.close();
        } catch (SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }


    // Example function to detect file type based on extension
    public static String getFileType(String filePath) {
        // Extract the file extension and return
        // In this example, I simply return based on the extension; you might need a more sophisticated detection
        String extension = filePath.substring(filePath.lastIndexOf(".") + 1);
        return extension; // This could be "txt", "jpg", etc.
    }



public static void retrieveFile(int fileId) {
    try {
        Connection connection = DriverManager.getConnection(url);
        String sql = "SELECT filename, data, password, downloads FROM Library WHERE Id=?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, fileId);
        ResultSet resultSet = statement.executeQuery();

        if (resultSet.next()) {
            String filename = resultSet.getString("filename");
            String filePassword = resultSet.getString("password");
            byte[] fileData = resultSet.getBytes("data");
            int downloads = resultSet.getInt("downloads");

            // Increment the downloads value
            downloads++;

            // Update the downloads value in the database
            String updateDownloadsSql = "UPDATE Library SET downloads = ? WHERE Id = ?";
            PreparedStatement updateDownloadsStatement = connection.prepareStatement(updateDownloadsSql);
            updateDownloadsStatement.setInt(1, downloads);
            updateDownloadsStatement.setInt(2, fileId);
            updateDownloadsStatement.executeUpdate();

            // Check if there's a password
            if (filePassword != null) {
                System.out.print("Enter password for the file: ");
                Scanner scanner = new Scanner(System.in);
                String userInputPassword = scanner.nextLine();

                if (!userInputPassword.equals(filePassword)) {
                    System.out.println("Incorrect password. Cannot retrieve the file.");
                    return;  // Exit the function if password is incorrect
                }
            }

            // Replace "demo.txt" with the actual filename from the database
            String file_path = "src/main/resources/" + filename;
            InputStream inputStream = new ByteArrayInputStream(fileData);
            OutputStream outputStream = new FileOutputStream(file_path);

            int bytesRead = -1;
            byte[] buffer = new byte[4096];
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            inputStream.close();
            outputStream.close();

            System.out.println("File retrieved successfully to: " + file_path);
        }

        resultSet.close();
        statement.close();
        connection.close();
    } catch (SQLException | IOException ex) {
        ex.printStackTrace();
    }
}


    //search filters
    public static void previewFileByID(int fileId) {
//        if (fileId > totalNumOfFile) {
//            System.out.println("Please enter a valid fileID");
//            return;
//        }

        try {
            Connection connection = DriverManager.getConnection(url);
            String sql = "SELECT Id, filename FROM  Library WHERE  Id=?";
            PreparedStatement statement = connection.prepareStatement(sql);

            statement.setInt(1, fileId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                System.out.println("\nfileID : " + resultSet.getInt(1) + ",  filename : " + resultSet.getString(2));
            }else{
                System.out.println("No files fo this ID");
                return;
            }

            connection.close();
        } catch (SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }
    public static void previewFileByUploaderID(int uploaderID) {
        try {
            Connection connection = DriverManager.getConnection(url);
            String sql = "SELECT Id, filename FROM Library WHERE uploaderID=?";
            PreparedStatement statement = connection.prepareStatement(sql);

            statement.setInt(1, uploaderID);
            ResultSet resultSet = statement.executeQuery();



            while (resultSet.next()) {
                System.out.println("\nfileID : " + resultSet.getInt("Id") + ", filename : " + resultSet.getString("filename"));
            }

            connection.close();
        } catch (SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    public static void previewFileByDate(String date) {
        try {
            Connection connection = DriverManager.getConnection(url);
            String sql = "SELECT Id, filename FROM Library WHERE date=?";
            PreparedStatement statement = connection.prepareStatement(sql);

            statement.setString(1, date);
            ResultSet resultSet = statement.executeQuery();

//            if (!resultSet.next()) {
//                System.out.println("No files uploaded on this date");
//                return;
//            }

            while (resultSet.next()) {
                System.out.println("\nfileID : " + resultSet.getInt("Id") + ", filename : " + resultSet.getString("filename"));
            }

            connection.close();
        } catch (SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    public static void previewFileByFilename(String filename) {
        try {
            Connection connection = DriverManager.getConnection(url);
            String sql = "SELECT Id, filename FROM Library WHERE filename LIKE ?";
            PreparedStatement statement = connection.prepareStatement(sql);

            // Using LIKE with % for wildcard search to match any filenames that contain the specified filename.
            statement.setString(1, "%" + filename + "%");
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                System.out.println("\nfileID : " + resultSet.getInt("Id") + ", filename : " + resultSet.getString("filename"));
            }

            connection.close();
        } catch (SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }




    public static void previewAllFiles() {
        try {
            Connection connection = DriverManager.getConnection(url);
            String sql = "SELECT Id, filename FROM  Library";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                System.out.println("\nfileID : " + resultSet.getInt(1) + ",  filename : " + resultSet.getString(2));
            }

            connection.close();
        } catch (SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }
        public static boolean compareID(int UserID, int fileID) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        try {
            connection = DriverManager.getConnection(url);
            String sql = "SELECT uploaderID FROM Library WHERE Id=?";
            statement = connection.prepareStatement(sql);
            statement.setInt(1, fileID);
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return UserID == resultSet.getInt(1);
            }
        } catch (SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (statement != null) statement.close();
                if (connection != null) connection.close();
            } catch (SQLException se) {
                se.printStackTrace();
            }
        }
        return false;
    }

    public static void deleteFile(int UserID, int fileId) {
        if (compareID(UserID, fileId)) {
            Connection connection = null;
            PreparedStatement statement = null;
            try {
                connection = DriverManager.getConnection(url);
                String sql = "DELETE FROM Library WHERE Id=?";
                statement = connection.prepareStatement(sql);
                statement.setInt(1, fileId);
                statement.executeUpdate();
                System.out.println("File deleted successfully");
            } catch (SQLException e) {
                System.err.println("Error performing database operation: " + e.getMessage());
            } finally {
                try {
                    if (statement != null) statement.close();
                    if (connection != null) connection.close();
                } catch (SQLException se) {
                    se.printStackTrace();
                }
            }
        } else {
            System.out.println("You are not the uploader of this file hence you cannot delete it");
        }
    }    
}
