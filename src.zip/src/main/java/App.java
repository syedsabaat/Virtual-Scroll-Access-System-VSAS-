import java.util.*;

public class App {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        String userType;
        // To sign up, need to go through GUEST
        do {
            System.out.println("How would you like to use the app? Choose from Guest, User or Admin.");
            System.out.println("NOTE: to sign up, please choose Guest.");
            System.out.print("Your choice: ");
            userType = input.nextLine().trim().toLowerCase();

            if (!(userType.equals("guest") || userType.equals("user") || userType.equals("admin"))) {
                System.out.println("Invalid choice. Please choose from Guest, User or Admin.");
                System.out.println();
            }

        } while (!(userType.equals("guest") || userType.equals("user") || userType.equals("admin")));


        switch (userType.toLowerCase().strip()) {
            case "guest":
                System.out.println("----------------------------------------------");
                System.out.println("Successfully logged in as a guest user");
                System.out.println("----------------------------------------------");

                viewGuestDashboard();
                break;

                case "admin":
                System.out.println("Successfully logged in as an admin");
                // Create an instance of the Admin class
                Admin admin = new Admin();
                // Call the admin dashboard method
                admin.viewAdminDashboard();
                break;

            case "user":
                viewUserDashboard();
                break;
            default:
                System.out.println("Please enter a valid choice.");
        }
    }

    public static void viewGuestDashboard() {
        Scanner input = new Scanner(System.in);

        while(true) {
            int response = 0;

            while (response < 1 || response > 3) {
                System.out.println();
                System.out.println("Guest Dashboard:  ");
                System.out.println("1 : Preview files");
                System.out.println("2 : Sign up");
                System.out.println("3 : exit");
                System.out.print("\nEnter your choice:  ");

                if (input.hasNextInt()) {
                    response = input.nextInt();

                    if (response < 1 || response > 3) {
                        System.out.println("Invalid choice. Please choose a valid option.");
                    }
                } else {
                    System.out.println("Please enter a number.");
                    input.next(); // consume the invalid input
                }
            }

            switch(response) {
                case 1:
                    int previewChoice = 0;

                    while (previewChoice < 1 || previewChoice > 2) {
                        System.out.println("\n1 : Preview all files");
                        System.out.println("2 : Preview a specific file");
                        System.out.print("\nEnter your choice:  ");

                        if (input.hasNextInt()) {
                            previewChoice = input.nextInt();

                            if (previewChoice < 1 || previewChoice > 2) {
                                System.out.println("Invalid choice. Please choose a valid option.");
                            }
                        } else {
                            System.out.println("Please enter a number.");
                            input.next(); // consume the invalid input
                        }
                    }

                    if (previewChoice == 1) {
                        System.out.println("----------------------------------------------");
                        FileSystem.previewAllFiles();
                        System.out.println("----------------------------------------------");
                    } else {
                        System.out.println("\nEnter the fileId of the file you want to preview");
                        System.out.print("File Id : ");
                        int fileId = input.nextInt();
                        System.out.println("----------------------------------------------");
                        FileSystem.previewFileByID(fileId);
                        System.out.println("----------------------------------------------");
                    }
                    break;

                case 2:
                    System.out.println("\nSigning up as a new user");
                    System.out.println("----------------------------------------------");
                    input.nextLine();

                    System.out.print("Enter your email: ");
                    String email = input.nextLine();

                    System.out.print("Enter your phone number: ");
                    String phoneNum = input.nextLine();

                    System.out.print("Enter your full name: ");
                    String fullName = input.nextLine();

                    System.out.print("Enter a username : ");
                    String username = input.nextLine(); // check if the userID is unique

                    System.out.print("Enter a userID for your account: ");
                    String userID = input.nextLine();

                    System.out.print("Enter a password for your account: ");
                    String password = input.nextLine();

                    // add this info to users table
                    User user = new User();
                    if (!user.checkDuplicateKeys(userID, username)) {
                        user.addUser(userID, phoneNum, fullName, username, email, password);
                    }

                case 3:
                    System.out.println("Exiting the app...");
                    System.exit(0);
                    break;
            }
        }
    }


    public static void viewUserDashboard() {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter your username:  ");
        String username = input.nextLine();

        System.out.print("Enter your password:  ");
        String password = input.nextLine();

        if (User.checkUserLogin(username,password)) {
            // here, set userID?? -> and make addUser a static method
            System.out.println("\n----------------------------------------------");
            System.out.println("Successfully logged in as a user");
            System.out.printf("Hey, %s!\n", username);
            System.out.println("----------------------------------------------\n");
            FileSystem.getRandomFile();

            //dashboard
            while(true) {
                System.out.println("User Dashboard: ");
                System.out.println("1 : Preview files and retrieve a file");
                System.out.println("2 : Upload a file to the Library");
                System.out.println("3 : Update profile information");
                System.out.println("4 : Delete a file from the Library ");
                System.out.println("5 : exit");

                System.out.print("\nEnter your choice:  ");
                int choice = input.nextInt();
                input.nextLine();

                switch(choice) {
                    case 1:
                        System.out.println("1 : Preview all files");
                        System.out.println("2 : Preview a specific file");
                        System.out.print("Enter your choice: ");
                        int previewChoice = input.nextInt();
                        input.nextLine();

                        if (previewChoice == 1) {
                            System.out.println();
                            System.out.println("Library");
                            System.out.println("----------------------------------------------");
                            FileSystem.previewAllFiles();
                            System.out.println("----------------------------------------------");
                        } else {
                            // preview a specific file hence will show search options
                            FileSearchDashboard();
                        }


                        System.out.print("Enter the file Id of the file you want to retrieve: ");
                        int fileId = input.nextInt();
                        input.nextLine();
                        FileSystem.retrieveFile(fileId);
                        break;

                    case 2:
                        System.out.print("Enter the path of the file you want to upload : ");
                        String file_path = input.nextLine();
                        System.out.print("Enter a password for the file or type 'None' if you want to keep it password free: ");
                        String file_password = input.nextLine();
                        // should add uploader ID and date of the file upload
                        FileSystem.addFile(file_path, file_password.strip(), User.getUserID());
                        break;

                    case 3:
                        System.out.println("Your current profile information is as follows:");
                        System.out.println();
                        User.showUserInfo(username);
                        System.out.println("----------------------------------------------\n");

                        System.out.println("Enter the field you want to update:");
                        System.out.println("0 : UserID");
                        System.out.println("1 : Phone number");
                        System.out.println("2 : Email");
                        System.out.println("3 : Full name");
                        System.out.println("4 : Username");
                        System.out.println("5 : Password");

                        int userChoice = input.nextInt();
                        input.nextLine();  // Consume newline left-over

                        getUserChoiceOfProfileUpdate(userChoice);
                        break;


                    case 4 :
                        System.out.print("Specify the fileID of the file you would like to delete: ");
                        int fileID = input.nextInt();
                        input.nextLine();
                        FileSystem.deleteFile(User.getUserID(),fileID);
                        break;




                    case 5:
                        System.out.println("Exiting the app...");
                        System.exit(0);
                        break;
                }
            }
        } else {
            System.out.println("Either the UserID or the password is invalid");
        }
    }

    public static void getUserChoiceOfProfileUpdate(int choice) {
        Scanner input = new Scanner(System.in);

        String updateColumn;
        String inputValue;

        switch(choice) {
            case 0:
                System.out.print("Enter new UserID: ");
                updateColumn = "UserID";
                inputValue = input.nextLine();
                while (User.checkUserIdOrUsernameTaken( "UserID", inputValue)) {
                    System.out.println("UserID is already taken. Please enter a new one:");
                    inputValue = input.nextLine();
                }
                break;

            case 1:
                System.out.print("Enter new phone number: ");
                updateColumn = "phone_num";
                inputValue = input.nextLine();
                break;

            case 2:
                System.out.print("Enter new email: ");
                updateColumn = "email";
                inputValue = input.nextLine();
                break;

            case 3:
                System.out.print("Enter new full name: ");
                updateColumn = "fullname";
                inputValue = input.nextLine();
                break;

            case 4:
                System.out.print("Enter new username: ");
                updateColumn = "username";
                inputValue = input.nextLine();

                while (User.checkUserIdOrUsernameTaken("username", inputValue)) {
                    System.out.println("Username is already taken. Please enter a new one:");
                    inputValue = input.nextLine();
                }
                break;

            case 5:
                System.out.print("Enter new password: ");
                updateColumn = "password";
                inputValue = PasswordHandler.encryptPassword(input.nextLine());  // Assuming you have this method for password encryption
                break;

            default:
                System.out.println("Invalid choice!");
                return;
        }

        User.updateUserProfile(updateColumn, inputValue);
    }

    public static void FileSearchDashboard(){
        Scanner input = new Scanner(System.in);

        int response = 0;

        while (response < 1 || response > 4) {
            System.out.println();
            System.out.println("1 : Search by fileID");
            System.out.println("2 : Search by file name");
            System.out.println("3 : Search by uploaderID");
            System.out.println("4 : Search by date");
            System.out.print("\nEnter your choice:  ");

            if (input.hasNextInt()) {
                response = input.nextInt();

                if (response < 1 || response > 3) {
                    System.out.println("Invalid choice. Please choose a valid option.");
                }
            } else {
                System.out.println("Please enter a number.");
                input.next(); // consume the invalid input
            }
        }

        switch (response) {
            case 1:
                System.out.println("Enter the fileID of the file you want to preview");
                System.out.print("File Id : ");
                int fileId = input.nextInt();

                System.out.println("----------------------------------------------");
                FileSystem.previewFileByID(fileId);
                System.out.println("----------------------------------------------");
                break;
            case 2:
                System.out.println("Enter the name of the file you want to preview");
                System.out.print("File name : ");
                input.nextLine();
                String fileName = input.nextLine();
                System.out.println();
                System.out.println("----------------------------------------------");
                FileSystem.previewFileByFilename(fileName);
                System.out.println("----------------------------------------------");
                break;
            case 3:
                System.out.println("Enter the uploaderID of the file you want to preview");
                System.out.print("Uploader ID : ");
                int uploaderID = input.nextInt();
                System.out.println("----------------------------------------------");
                FileSystem.previewFileByUploaderID(uploaderID);
                System.out.println("----------------------------------------------");
                break;
            case 4:
                System.out.println("Enter the date of the file you want to preview");
                System.out.print("Date : ");
                input.nextLine();
                String date = input.nextLine();

                System.out.println("----------------------------------------------");
                FileSystem.previewFileByDate(date);
                System.out.println("----------------------------------------------");
                break;

        }
    }
}
