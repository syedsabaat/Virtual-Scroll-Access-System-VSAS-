import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.sql.*;

import static org.junit.jupiter.api.Assertions.*;

public class UserTest {

    private String url = "jdbc:sqlite:database.db";

    private String phoneNum = "0400000000";
    private String email = "test@gmail.com";
    private String fullName = "JOHN DOE";
    private String userID = "100011011";
    private String username = "test123";
    private String password = "1";



    private final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    private String getOutput() {
        System.setOut(originalOut);
        return outputStream.toString();
    }




    private String[][] accessDatabase() {
        String[][] instance = null;

        try{
            Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db");

            String selectQuery = "SELECT COUNT(*) FROM Users";
            ResultSet resultSet = connection.createStatement().executeQuery(selectQuery);
            int count = resultSet.getInt(1);

            instance = new String[count][6];

            selectQuery = "SELECT * FROM Users";
            resultSet = connection.createStatement().executeQuery(selectQuery);

            count = 0;
            while (resultSet.next()) {
                instance[count][0] = String.valueOf(resultSet.getInt("Phone_num"));
                instance[count][1] = resultSet.getString("email");
                instance[count][2] = resultSet.getString("fullname");
                instance[count][3] = String.valueOf(resultSet.getInt("UserID"));
                instance[count][4] = resultSet.getString("Username");
                instance[count][5] = resultSet.getString("password");

                count++;
            }

            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }

        return instance;
    }

    private String[] getInstance() {
        String[] instance = null;

        try{
            Connection connection = DriverManager.getConnection("jdbc:sqlite:database.db");

            String selectQuery = "SELECT * FROM Users WHERE UserID = 100011011";
            ResultSet resultSet = connection.createStatement().executeQuery(selectQuery);

            if (resultSet.next()) {
                instance = new String[6];
                instance[0] = String.valueOf(resultSet.getInt("Phone_num"));
                instance[1] = resultSet.getString("email");
                instance[2] = resultSet.getString("fullname");
                instance[3] = String.valueOf(resultSet.getInt("UserID"));
                instance[4] = resultSet.getString("Username");
                instance[5] = resultSet.getString("password");
            }

            connection.close();

        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }

        return instance;
    }


    @Test
    void testAddUserValid() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);

        String[] instance = getInstance();

        assertEquals("400000000", instance[0]);
        assertEquals(email, instance[1]);
        assertEquals(fullName, instance[2]);
        assertEquals(userID, instance[3]);
        assertEquals(username, instance[4]);

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testAddUserInvalidUserIdNull() {
        User user = new User();
        user.addUser(null, phoneNum, fullName, username, email, password);

        String[] instance = getInstance();

        assertNull(instance);
    }

    @Test
    void testAddUserInvalidPhone() {
        User user = new User();
        user.addUser(userID, "INVALID", fullName, username, email, password);

        String[] instance = getInstance();

        assertNull(instance);
    }

    @Test
    void testAddUserInvalidPhoneLength() {
        User user = new User();
        user.addUser(userID, "111111111111", fullName, username, email, password);

        String[] instance = getInstance();

        assertNull(instance);
    }

    @Test
    void testAddUserInvalidPhoneNull() {
        User user = new User();
        user.addUser(userID, null, fullName, username, email, password);

        String[] instance = getInstance();

        assertNull(instance);
    }

    @Test
    void testAddUserInvalidFullNameNull() {
        User user = new User();
        user.addUser(userID, phoneNum, null, username, email, password);

        String[] instance = getInstance();

        assertNull(instance);
    }

    @Test
    void testAddUserInvalidUsernameNull() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, null, email, password);

        String[] instance = getInstance();

        assertNull(instance);
    }

    @Test
    void testAddUserInvalidEmailNull() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, null, password);

        String[] instance = getInstance();

        assertNull(instance);
    }

    @Test
    void testAddUserInvalidPasswordNull() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, null);

        String[] instance = getInstance();
        assertNull(instance);
    }



    @Test
    void testCheckDuplicateKeysValid() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);

        assertFalse(User.checkDuplicateKeys("0000000000", "NAME"));

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testCheckDuplicateKeysInvalidUserId() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);

        assertTrue(user.checkDuplicateKeys(userID, "NAME"));

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testCheckDuplicateKeysInvalidUsername() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);

        assertTrue(user.checkDuplicateKeys("0000000000", username));

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }



    @Test
    void testCheckDuplicateKeysInvalidUserIdStr() {
        User user = new User();

        assertTrue(user.checkDuplicateKeys("INVALID", username));
    }

    @Test
    void testCheckDuplicateKeysInvalidUserIdNull() {
        User user = new User();

        assertTrue(user.checkDuplicateKeys(null, username));
    }

    @Test
    void testCheckDuplicateKeysInvalidUsernameNull() {
        User user = new User();

        assertTrue(user.checkDuplicateKeys(userID, null));
    }



    @Test
    void testCheckUserLoginValid() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);

        assertTrue(user.checkDuplicateKeys(username, password));

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testCheckUserLoginInvalid() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);

        assertFalse(user.checkUserLogin(username, "TEST"));
        assertFalse(user.checkUserLogin("NAME", password));
        assertFalse(user.checkUserLogin("NAME", "TEST"));

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testCheckUserLoginInvalidNull() {
        User user = new User();

        assertFalse(user.checkUserLogin(null, "TEST"));
        assertFalse(user.checkUserLogin("NAME", null));
    }



    @Test
    void testShowUserInfoValid() {
        System.setOut(new PrintStream(outputStream));
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);

        user.showUserInfo(username);

        String output = getOutput();
        String expectedOutput = "User added successfully. Your userID is 100011011. Remember this to login in the future.\n"
                + "UserID: 100011011\n" + "Username: test123\n" + "Full Name: JOHN DOE\n" + "Email: test@gmail.com\n"
                + "Phone Number: 400000000\n" + "Password: **********\n";

        assertEquals(expectedOutput, output);

        System.setOut(originalOut);

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testShowUserInfoInvalid() {
        System.setOut(new PrintStream(outputStream));
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);

        user.showUserInfo("NAME");

        String output = getOutput();
        String expectedOutput = "User added successfully. Your userID is 100011011. Remember this to login in the future.\n"
                + "No user found with username: NAME\n";

        assertEquals(expectedOutput, output);

        System.setOut(originalOut);

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testShowUserInfoInvalidNull() {
        User user = new User();
        System.setOut(new PrintStream(outputStream));

        user.showUserInfo(null);

        String output = getOutput();
        String expectedOutput = "Please enter a valid username.\n";

        assertEquals(expectedOutput, output);

        System.setOut(originalOut);
    }






    @Test
    void testGetUserId() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);

        assertEquals(user.getUserID(), Integer.parseInt(userID));

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }




    @Test
    void testUpdateUserProfileValidUserID() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);
        user.updateUserProfile("UserID", "100011011100011011");

        boolean exist = false;

        try{
            Connection connection = DriverManager.getConnection(url);
            String selectQuery = "SELECT * FROM Users WHERE UserID = 100011011100011011";
            ResultSet resultSet = connection.createStatement().executeQuery(selectQuery);
            if (resultSet.next()) {
                exist = true;
            }
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }

        assertTrue(exist);

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testUpdateUserProfileValidPhone() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);
        user.updateUserProfile("phone_num", "0400000001");

        String[] instance = getInstance();

        assertEquals("400000001", instance[0]);
        assertEquals(email, instance[1]);
        assertEquals(fullName, instance[2]);
        assertEquals(userID, instance[3]);
        assertEquals(username, instance[4]);

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testUpdateUserProfileValidEmail() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);
        user.updateUserProfile("email", "example@gmail.com");

        String[] instance = getInstance();

        assertEquals("400000000", instance[0]);
        assertEquals("example@gmail.com", instance[1]);
        assertEquals(fullName, instance[2]);
        assertEquals(userID, instance[3]);
        assertEquals(username, instance[4]);

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testUpdateUserProfileValidFullName() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);
        user.updateUserProfile("fullname", "James Doe");

        String[] instance = getInstance();

        assertEquals("400000000", instance[0]);
        assertEquals(email, instance[1]);
        assertEquals("JAMES DOE", instance[2]);
        assertEquals(userID, instance[3]);
        assertEquals(username, instance[4]);

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testUpdateUserProfileValidUsername() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);
        user.updateUserProfile("username", "test123456");

        String[] instance = getInstance();

        assertEquals("400000000", instance[0]);
        assertEquals(email, instance[1]);
        assertEquals(fullName, instance[2]);
        assertEquals(userID, instance[3]);
        assertEquals("test123456", instance[4]);

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testUpdateUserProfileValidPassword() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);

        String newPassword = PasswordHandler.encryptPassword("10");
        user.updateUserProfile("password", newPassword);

        String[] instance = getInstance();

        assertEquals(newPassword, instance[5]);

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testUpdateUserProfileInvalidNull() {
        System.setOut(new PrintStream(outputStream));
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);
        user.updateUserProfile(null, null);

        String output = getOutput();
        String expectedOutput = "User added successfully. Your userID is 100011011. Remember this to login in the future.\n"
                + "Please enter a valid entry.\n";

        assertEquals(expectedOutput, output);

        System.setOut(originalOut);

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testUpdateUserProfileInvalidColumnNull() {
        System.setOut(new PrintStream(outputStream));
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);
        user.updateUserProfile(null, "TEST");

        String output = getOutput();
        String expectedOutput = "User added successfully. Your userID is 100011011. Remember this to login in the future.\n"
                + "Please enter a valid entry.\n";

        assertEquals(expectedOutput, output);

        System.setOut(originalOut);

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testUpdateUserProfileInvalidValueNull() {
        System.setOut(new PrintStream(outputStream));
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);
        user.updateUserProfile("TEST", null);

        String output = getOutput();
        String expectedOutput = "User added successfully. Your userID is 100011011. Remember this to login in the future.\n"
                + "Please enter a valid entry.\n";

        assertEquals(expectedOutput, output);

        System.setOut(originalOut);

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }




    @Test
    void testCheckUserIdOrUsernameTakenValidTrue() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);

        assertTrue(user.checkUserIdOrUsernameTaken("UserID", userID));
        assertTrue(user.checkUserIdOrUsernameTaken("Username", username));

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testCheckUserIdOrUsernameTakenValidFalse() {
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);

        assertFalse(user.checkUserIdOrUsernameTaken("UserID", "100011010"));
        assertFalse(user.checkUserIdOrUsernameTaken("Username", "test123456"));

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testCheckUserIdOrUsernameTakenInvalidNull() {
        System.setOut(new PrintStream(outputStream));
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);
        boolean check = user.checkUserIdOrUsernameTaken(null, null);

        String output = getOutput();
        String expectedOutput = "User added successfully. Your userID is 100011011. Remember this to login in the future.\n"
                + "Please enter a valid entry.\n";

        assertEquals(expectedOutput, output);
        assertTrue(check);

        System.setOut(originalOut);

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testCheckUserIdOrUsernameTakenInvalidColumnNull() {
        System.setOut(new PrintStream(outputStream));
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);
        user.checkUserIdOrUsernameTaken(null, "TEST");

        String output = getOutput();
        String expectedOutput = "User added successfully. Your userID is 100011011. Remember this to login in the future.\n"
                + "Please enter a valid entry.\n";

        assertEquals(expectedOutput, output);

        System.setOut(originalOut);

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @Test
    void testCheckUserIdOrUsernameTakenInvalidValueNull() {
        System.setOut(new PrintStream(outputStream));
        User user = new User();
        user.addUser(userID, phoneNum, fullName, username, email, password);
        user.checkUserIdOrUsernameTaken("TEST", null);

        String output = getOutput();
        String expectedOutput = "User added successfully. Your userID is 100011011. Remember this to login in the future.\n"
                + "Please enter a valid entry.\n";

        assertEquals(expectedOutput, output);

        System.setOut(originalOut);

        // remove instance
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 100011011");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }
}

