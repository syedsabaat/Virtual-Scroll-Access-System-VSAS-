import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class FileSystemTest {

    private static String url = "jdbc:sqlite:database.db";
    private static int count;


    private final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;

    private String getOutput() {
        System.setOut(originalOut);
        return outputStream.toString();
    }

    @BeforeAll
    static void addTestFilesToLibrary() {
        User user = new User();
        user.addUser("10011001", "0000000000", "TEST", "TEST", "TEST", "TEST");

        FileSystem.addFile("src/main/resources/test_files/test1.txt", "None", 10011001);
        FileSystem.addFile("src/main/resources/test_files/test2.txt", "None", 10011001);
        FileSystem.addFile("src/main/resources/test_files/test3.txt", "None", 10011001);
//        FileSystem.addFile("src/main/resources/test_files/test4.txt", "None", 10011001);
//        FileSystem.addFile("src/main/resources/test_files/test5.txt", "None", 10011001);

        try{
            Connection connection = DriverManager.getConnection(url);
            String selectQuery = "SELECT COUNT(*) FROM Library";
            ResultSet resultSet = connection.createStatement().executeQuery(selectQuery);
            count = resultSet.getInt(1);
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }

    @AfterAll
    static void removeTestFilesToLibrary() {
        try{
            Connection connection = DriverManager.getConnection(url);
            connection.createStatement().executeUpdate("DELETE FROM Library WHERE uploaderID = 10011001;");
            connection.createStatement().executeUpdate("DELETE FROM Users WHERE UserID = 10011001;");
            connection.close();
        } catch(SQLException e) {
            System.err.println("Error performing database operation: " + e.getMessage());
        }
    }




    @Test
    void testGetRandomFile() {
        System.setOut(new PrintStream(outputStream));

        FileSystem.getRandomFile();

        String output = getOutput();
        String expectedOutput = "        *****Scroll of the Day*****\n"
                + "----------------------------------------------\n";

        assertTrue(output.contains(expectedOutput));

        System.setOut(originalOut);
    }

    @Test
    void testGetFileType() {
        String filePath = "src/main/resources/test_files/test.txt";
        String extension = filePath.substring(filePath.lastIndexOf(".") + 1);

        assertEquals(FileSystem.getFileType(filePath), extension);
    }

    @Test
    void testPreviewFileByIDValid() {
        System.setOut(new PrintStream(outputStream));

        FileSystem.previewFileByID(count); // this should be test3.txt

        String output = getOutput();
        String expectedOutput = "\nfileID : " + count + ",  filename : " + "test3.txt\n";

        assertEquals(expectedOutput, output);

        System.setOut(originalOut);
    }

//    @Test
//    void testPreviewFileByIDInvalidFileID() {
//        System.setOut(new PrintStream(outputStream));
//
//        FileSystem.previewFileByID(count+3); // this should be test3.txt
//
//        String output = getOutput();
//        String expectedOutput = "Please enter a valid fileID\n";
//
//        assertEquals(expectedOutput, output);
//
//        System.setOut(originalOut);
//    }


    @Test
    void testPreviewAllFiles() {
        System.setOut(new PrintStream(outputStream));

        FileSystem.previewAllFiles();

        String output = getOutput();
        String expectedOutput = "\nfileID : " + (count-2) + ",  filename : " + "test1.txt\n" +
                "\nfileID : " + (count-1) + ",  filename : " + "test2.txt\n" +
                "\nfileID : " + count + ",  filename : " + "test3.txt\n";

        assertTrue(output.contains(expectedOutput));
    }
}

