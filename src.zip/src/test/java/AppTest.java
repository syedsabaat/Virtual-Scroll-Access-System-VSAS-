import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.*;

public class AppTest {

    private final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    private final InputStream originalIn = System.in;

    @BeforeEach
    public void setUp() {
        System.setOut(new PrintStream(outputStream));
    }

    @AfterEach
    public void tearDown() {
        System.setOut(originalOut);
        System.setIn(originalIn);
    }

    private void provideInput(String data) {
        System.setIn(new ByteArrayInputStream(data.getBytes()));
    }

    private String getOutput() {
        System.setOut(originalOut);
        return outputStream.toString();
    }

    /* 
    @Test
    public void testGuestSignupAndUserLogin() {
        // Simulate user input for guest signup and user login
        String input = "guest\nsignup\nexample@example.com\n1234567890\nJohn Doe\njohndoe\npassword123\n" +
                "user\n1\npassword123\n";
        provideInput(input);
    
        // Capture the actual output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outputStream));
    
        App.main(new String[]{});
    
        // Restore the original output stream
        System.setOut(originalOut);
    
        String output = outputStream.toString();
        
        // Define the expected output based on the actual behavior of your App class
        String expectedOutput = "How would you like to use the app? Guest, User or Admin?\n" +
                "Enter your email\nEnter your Phone number\nEnter your full name\nEnter username\n" +
                "Enter a password for your account\n" +
                "Enter your userID\nEnter your password\nSuccessfully logged in\n" +
                "Enter the fileId of the file you want to retrieve\n";
    
        assertEquals(expectedOutput, output);
    }*/

    @Test
    public void testAdminAccess() {
        // Simulate user input for admin access
        String input = "admin\n";
        provideInput(input);

        App.main(new String[]{});

        String output = getOutput();
        String expectedOutput = "How would you like to use the app? Choose from Guest, User or Admin.\n" +
                "NOTE: to sign up, please choose Guest.\n" + "Do admin stuff\n";
        assertEquals(expectedOutput, output);
    }
/*
    @Test
    public void testInvalidUserLogin() {
        // Simulate user input for invalid user login
        String input = "user\n1\nwrongpassword\n";
        provideInput(input);
    
        // Capture the actual output
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outputStream));
    
        App.main(new String[]{});
    
        // Restore the original output stream
        System.setOut(originalOut);
    
        String output = outputStream.toString();
    
        // Define the expected output for an invalid login attempt
        String expectedOutput = "How would you like to use the app? Guest, User or Admin?\n" +
                "Enter your userID\nEnter your password\nEither the UserID or the password is invalid\n";
    
        assertEquals(expectedOutput, output);
    }*/

//    @Test
//    public void testGuestContinue() {
//        // Simulate user input for guest continue
//        String input = "guest\ncontinue\n";
//        provideInput(input);
//
//        App.main(new String[]{});
//
//        String output = getOutput();
//        String expectedOutput = "How would you like to use the app? Choose from Guest, User or Admin.\n" +
//                "Type 'signup' if you want to sign up as a user OR type 'continue' if you want to continue as a guest.\n";
//        assertEquals(expectedOutput, output);
//    }
}
