import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class PasswordHandlerTest {

    @Test
    void testEncryptPassword() {
        String password = "TEST";
        String encPassword = PasswordHandler.encryptPassword(password);

        assertNotEquals(password, encPassword);
    }

    @Test
    void testCheckPassword() {
        String password = "TEST";
        String encPassword = PasswordHandler.encryptPassword(password);

        assertTrue(PasswordHandler.checkPassword(password, encPassword));
        assertFalse(PasswordHandler.checkPassword("WRONG", encPassword));
    }
}
